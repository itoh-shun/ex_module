<?php

namespace framework\Exception;

use Exception;

class ClassNotFoundException extends Exception
{
}
