<?php

namespace framework\Enterprise\CommonModels;

interface GateInterface
{
    public function can();
}
