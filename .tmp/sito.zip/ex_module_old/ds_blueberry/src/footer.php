<?php
echo <<<EOD
<footer class="mypage">
	<p class="copyright">
EOD;
?>
<?php include ('ex_module/ds_blueberry/src/copyright_myarea.php'); ?>
<?php
echo <<<EOD
	</p>
</footer>
EOD;
?>