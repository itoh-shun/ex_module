<?php
return [
    "debug" => false,
    "name" => "ex_module",
    "timezone" => "Asia/Tokyo",
    "locale" => "ja",
    "version" => "0.0.1"
];
