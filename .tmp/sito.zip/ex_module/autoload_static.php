<?php 
require_once 'ex_module/config/app.php';
require_once 'ex_module/app/Interfaces/ExModulePluginInterface.php';
require_once 'ex_module/app/UseCase/ExModuleSettings.php';
require_once 'ex_module/app/Exceptions/ExceptionHandler.php';
require_once 'ex_module/app/Http/Controllers/Web/ExModuleController.php';
require_once 'ex_module/ex_moduleApplication.php';
